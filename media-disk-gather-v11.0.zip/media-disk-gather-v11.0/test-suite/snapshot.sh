#!/bin/bash
# Zeigt den physischen Zustand aller Disks (Pfad + Grösse), sortiert
for d in cache disk1 disk2 disk10; do
    find "/mnt/$d" -mindepth 1 \( -type f -printf "%p\t%s\n" -o -type d -empty -printf "%p\t<leer>\n" \) 2>/dev/null
done | sort
