#!/bin/bash
# Baut die simulierte Unraid-Umgebung neu auf:
#   /mnt/cache, /mnt/disk1, /mnt/disk2, /mnt/disk10  (physische "Disks", alle auf ext4)
#   /mnt/user = mergerfs-Union (Reihenfolge wie shfs: cache, disk1, disk2, disk10)
set -euo pipefail

for d in cache disk1 disk2 disk10; do
    find "/mnt/$d" -mindepth 1 -delete 2>/dev/null || true
done
mkdir -p /mnt/disks   # Unassigned-Devices-Mountpoint wie auf echtem Unraid

mk() { # mk <pfad> <groesse>   (zufälliger Inhalt)
    mkdir -p "$(dirname "$1")"
    head -c "$2" /dev/urandom > "$1"
}

# ---------- Filme ----------
# A: Sidecars auf disk2, Film auf disk1  -> Sidecars sollen nach disk1
mk "/mnt/disk1/Filme/Alpha (2020)/Alpha (2020).mkv" 5M
mk "/mnt/disk2/Filme/Alpha (2020)/Alpha (2020).nfo" 1K
mk "/mnt/disk2/Filme/Alpha (2020)/poster.jpg" 2K

# B: identisches Duplikat auf disk1 und disk2
mk "/mnt/disk1/Filme/Bravo (2019)/Bravo (2019).mkv" 3M
mkdir -p "/mnt/disk2/Filme/Bravo (2019)"
cp "/mnt/disk1/Filme/Bravo (2019)/Bravo (2019).mkv" "/mnt/disk2/Filme/Bravo (2019)/"

# C: Film auf Cache, nfo auf disk2
mk "/mnt/cache/Filme/Charlie (2021)/Charlie (2021).mkv" 4M
mk "/mnt/disk2/Filme/Charlie (2021)/Charlie (2021).nfo" 1K

# D: Ordner NUR auf Cache
mk "/mnt/cache/Filme/Delta (2022)/Delta (2022).mkv" 2M
mk "/mnt/cache/Filme/Delta (2022)/Delta (2022).nfo" 1K

# E: Film auf disk1, Sidecars auf disk10  (Präfix disk1 vs disk10)
mk "/mnt/disk1/Filme/Echo (2018)/Echo (2018).mkv" 6M
mk "/mnt/disk10/Filme/Echo (2018)/Echo (2018).nfo" 1K
mk "/mnt/disk10/Filme/Echo (2018)/Echo (2018).de.srt" 3K

# F: vollständige Kopie auf disk1, abgebrochene (verkürzte) Kopie auf disk2
mk "/mnt/disk1/Filme/Foxtrot (2017)/Foxtrot (2017).mkv" 8M
mkdir -p "/mnt/disk2/Filme/Foxtrot (2017)"
head -c 1M "/mnt/disk1/Filme/Foxtrot (2017)/Foxtrot (2017).mkv" > "/mnt/disk2/Filme/Foxtrot (2017)/Foxtrot (2017).mkv"

# G: Exclude per Datei (User-Pfad und physischer Pfad)
mk "/mnt/disk1/Filme/Golf (2016)/Golf (2016).mkv" 2M
mk "/mnt/disk2/Filme/Golf (2016)/Golf (2016).nfo" 1K
mk "/mnt/disk2/Filme/Golf (2016)/fanart.jpg" 2K

# H: Exclude per Ordner-Pfad (erwartet: ganzer Ordner ignoriert)
mk "/mnt/disk1/Filme/Hotel (2015)/Hotel (2015).mkv" 2M
mk "/mnt/disk2/Filme/Hotel (2015)/Hotel (2015).nfo" 1K

# I: Sonderzeichen
SP="India & Juliet's [Director's Cut] (2014) äöü \$x #1"
mk "/mnt/disk1/Filme/$SP/$SP.mkv" 2M
mk "/mnt/disk2/Filme/$SP/$SP.nfo" 1K


# P: identische Kopie auf Array und Cache -> Cache-Kopie ist Duplikat
mk "/mnt/disk1/Filme/Papa (2009)/Papa (2009).mkv" 3M
mkdir -p "/mnt/cache/Filme/Papa (2009)"
cp "/mnt/disk1/Filme/Papa (2009)/Papa (2009).mkv" "/mnt/cache/Filme/Papa (2009)/"

# Q: verkürzte Kopie auf disk1, vollständige auf dem Cache -> darf NICHT gelöscht werden
mk "/mnt/cache/Filme/Quebec (2008)/Quebec (2008).mkv" 4M
mkdir -p "/mnt/disk1/Filme/Quebec (2008)"
head -c 1M "/mnt/cache/Filme/Quebec (2008)/Quebec (2008).mkv" > "/mnt/disk1/Filme/Quebec (2008)/Quebec (2008).mkv"

# K: leerer Ordner (z.B. von Radarr angelegt, Download läuft noch)
mkdir -p "/mnt/disk2/Filme/Lima (2012)"

# L: verschachtelte leere Ordner
mkdir -p "/mnt/disk2/Filme/Mike (2011)/extras/featurettes"

# lose Datei direkt im Share-Root
mk "/mnt/disk2/Filme/loose.mkv" 1M

# ---------- Serien ----------
# S1: Season 01 auf disk1, Season 02 auf disk2 (Ordner nobody:users 0777), e03 auf Cache
mk "/mnt/disk1/Serien/Show One/Season 01/Show One - S01E01.mkv" 5M
mk "/mnt/disk1/Serien/Show One/Season 01/Show One - S01E02.mkv" 5M
mk "/mnt/disk2/Serien/Show One/Season 02/Show One - S02E01.mkv" 3M
mk "/mnt/disk2/Serien/Show One/Season 02/Show One - S02E02.mkv" 3M
mk "/mnt/cache/Serien/Show One/Season 02/Show One - S02E03.mkv" 2M
chown -R 99:100 /mnt/disk1/Serien /mnt/disk2/Serien /mnt/cache/Serien
chmod -R 0777 /mnt/disk1/Serien /mnt/disk2/Serien /mnt/cache/Serien

# S2: verteilt über disk1 (2M), disk2 (4M), disk10 (1M) -> Ziel disk2
mk "/mnt/disk1/Serien/Show Two/Season 01/Show Two - S01E01.mkv" 2M
mk "/mnt/disk2/Serien/Show Two/Season 01/Show Two - S01E02.mkv" 2M
mk "/mnt/disk2/Serien/Show Two/Season 01/Show Two - S01E03.mkv" 2M
mk "/mnt/disk10/Serien/Show Two/Season 01/Show Two - S01E04.mkv" 1M

# Exclude-Datei
cat > /mnt/cache/exclude.txt <<EOF
# Kommentar
/mnt/user/Filme/Golf (2016)/Golf (2016).nfo
/mnt/disk2/Filme/Golf (2016)/fanart.jpg
/mnt/user/Filme/Hotel (2015)
EOF

# Union mounten (falls nicht schon)
if ! mountpoint -q /mnt/user; then
    mkdir -p /mnt/user
    mergerfs -o category.search=ff,category.create=ff,cache.attr=0,cache.entry=0,cache.negative_entry=0,cache.files=off,allow_other \
        /mnt/cache:/mnt/disk1:/mnt/disk2:/mnt/disk10 /mnt/user
fi
echo "Fixture bereit."
