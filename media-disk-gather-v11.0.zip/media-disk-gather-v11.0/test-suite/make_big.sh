#!/bin/bash
# make_big.sh <anzahl_filme>  — je Film 5 Dateien, 4 auf disk1, 1 (nfo) auf disk2 -> jede Gruppe erzeugt einen Move
set -euo pipefail
n="$1"
for d in cache disk1 disk2 disk10; do find "/mnt/$d" -mindepth 1 -delete 2>/dev/null || true; done
python3 - "$n" <<'EOF'
import os, sys
n = int(sys.argv[1])
for i in range(n):
    f = f"Film {i:05d} (20{i%25:02d})"
    d1 = f"/mnt/disk1/Filme/{f}"; d2 = f"/mnt/disk2/Filme/{f}"
    os.makedirs(d1, exist_ok=True); os.makedirs(d2, exist_ok=True)
    for name in (f"{f}.mkv", f"{f}.de.srt", "poster.jpg", "fanart.jpg"):
        with open(os.path.join(d1, name), "wb") as fh: fh.write(b"x" * 1024)
    with open(os.path.join(d2, f"{f}.nfo"), "wb") as fh: fh.write(b"x" * 512)
EOF
echo "$(find /mnt/disk1 /mnt/disk2 -type f | wc -l) Dateien angelegt"
