#!/bin/bash
# test_suite.sh <ordner-mit-consolidate_master.sh>
# Führt alle Szenarien gegen eine simulierte Unraid-Umgebung aus (siehe make_fixture.sh).
# Voraussetzungen: root, mergerfs, rsync. Jeder Test startet mit frischer Fixture.
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SUT="$(cd "$1" && pwd)"
WORK="$HERE/work_$(basename "$SUT")"; rm -rf "$WORK"; mkdir -p "$WORK/logs"
LOG="$WORK/logs/consolidate.log"
PASS=0; FAIL=0; RESULTS=()

ini() {  # ini <extra-zeilen...>  schreibt consolidate.ini ins SUT
    cat > "$SUT/consolidate.ini" <<EOF
BASE_DIRS=(/mnt/user/Filme /mnt/user/Serien)
LOGFILE="$LOG"
ARRAY_PATTERN="/mnt/disk*"
CACHE_PATTERN="/mnt/cache"
EXCLUDE_FILE="/mnt/cache/exclude.txt"
DRYRUN=true
MIN_FREE_GB=1
EOF
    for l in "$@"; do echo "$l" >> "$SUT/consolidate.ini"; done
}
fresh() { "$HERE/make_fixture.sh" >/dev/null; rm -f "$LOG"; ini "$@"; }
run1() { # ein Lauf, Ausgabe (max. 2 MB) + exit code
    ( cd "$SUT" && timeout 120 ./consolidate_master.sh "$@" 2>&1; echo "__RC=$?" ) | head -c 2000000 > "$WORK/last.out"
    RC=$(grep -oE '__RC=[0-9]+' "$WORK/last.out" | tail -1 | cut -d= -f2); RC=${RC:-124}
    OUT=$(sed 's/__RC=[0-9]*//; s/\r/\n/g; s/\x1b\[[0-9;]*[A-Za-z]//g' "$WORK/last.out")
}
check() { # check <id> <beschreibung> <bedingung...>
    local id="$1" desc="$2"; shift 2
    if "$@"; then ((PASS++)); RESULTS+=("PASS  $id  $desc"); else ((FAIL++)); RESULTS+=("FAIL  $id  $desc"); fi
}
snap() { "$HERE/snapshot.sh" | md5sum; }
nfiles() { find "$@" -type f 2>/dev/null | wc -l; }
summary_val() { printf '%s\n' "$OUT" | grep -E "^$1" | head -1 | grep -oE '[0-9]+$'; }

SP="India & Juliet's [Director's Cut] (2014) äöü \$x #1"

# ---------------- Standard-Livelauf (--run) ----------------
fresh; run1 --run; LIVE_OUT="$OUT"
check T01 "Sidecars von disk2 zum Film auf disk1 verschoben (Alpha)" \
    test -f "/mnt/disk1/Filme/Alpha (2020)/Alpha (2020).nfo" -a -f "/mnt/disk1/Filme/Alpha (2020)/poster.jpg" -a ! -e "/mnt/disk2/Filme/Alpha (2020)/Alpha (2020).nfo"
check T02 "Identisches Duplikat: genau eine Kopie bleibt (Bravo)" \
    test "$(nfiles /mnt/disk1/Filme/Bravo* /mnt/disk2/Filme/Bravo*)" = 1
check T03 "Ohne --include-cache bleibt die Cache-Datei liegen (Charlie)" \
    test -f "/mnt/cache/Filme/Charlie (2021)/Charlie (2021).mkv" -a -f "/mnt/disk2/Filme/Charlie (2021)/Charlie (2021).nfo"
check T05 "Sidecars von disk10 zum Film auf disk1 verschoben (Echo, Präfix disk1/disk10)" \
    test -f "/mnt/disk1/Filme/Echo (2018)/Echo (2018).nfo" -a -f "/mnt/disk1/Filme/Echo (2018)/Echo (2018).de.srt" -a "$(nfiles /mnt/disk10/Filme)" = 0
check T06 "Vollständige 8-MB-Kopie überlebt, verkürzte Kopie wird nicht bevorzugt (Foxtrot)" \
    test "$(stat -c%s "/mnt/disk1/Filme/Foxtrot (2017)/Foxtrot (2017).mkv" 2>/dev/null)" = 8388608
check T07 "Exclude per Dateipfad (User- und Disk-Pfad) wird respektiert (Golf)" \
    test -f "/mnt/disk2/Filme/Golf (2016)/Golf (2016).nfo" -a -f "/mnt/disk2/Filme/Golf (2016)/fanart.jpg"
check T08 "Exclude per Ordnerpfad wird respektiert (Hotel)" \
    test -f "/mnt/disk2/Filme/Hotel (2015)/Hotel (2015).nfo"
check T09 "Sonderzeichen in Pfaden (&, ', [], äöü, \$, #)" \
    test -f "/mnt/disk1/Filme/$SP/$SP.nfo" -a -f "/mnt/disk1/Filme/$SP/$SP.mkv"
check T10 "Verschachtelte leere Ordner komplett entfernt, Share-Wurzel bleibt (Mike, Lima)" \
    test ! -e "/mnt/disk2/Filme/Mike (2011)" -a ! -e "/mnt/disk2/Filme/Lima (2012)" -a -d /mnt/disk2/Filme -a -d /mnt/disk10/Filme
check T11 "Lose Datei im Share-Root bleibt unangetastet" \
    test -f /mnt/disk2/Filme/loose.mkv
check T12 "Neu angelegter Zielordner übernimmt Besitzer/Rechte der Quelle (nobody:users 0777)" \
    test "$(stat -c '%u:%g %a' "/mnt/disk1/Serien/Show One/Season 02" 2>/dev/null)" = "99:100 777"
check T13 "Serie mit Episoden auf 3 Disks landet komplett auf der Disk mit den meisten Bytes (Show Two -> disk2)" \
    test "$(nfiles "/mnt/disk2/Serien/Show Two")" = 4 -a "$(nfiles "/mnt/disk1/Serien/Show Two" "/mnt/disk10/Serien/Show Two")" = 0
check T21 "Identische Cache-Kopie einer Array-Datei wird als Duplikat entfernt (Papa)" \
    test ! -e "/mnt/cache/Filme/Papa (2009)/Papa (2009).mkv" -a -f "/mnt/disk1/Filme/Papa (2009)/Papa (2009).mkv"
check T22 "Ungleiche Cache-Kopie (vollständig, Array-Kopie verkürzt) wird NICHT gelöscht (Quebec)" \
    test -f "/mnt/cache/Filme/Quebec (2008)/Quebec (2008).mkv"
moved=$(printf '%s' "$LIVE_OUT" | grep -oE 'Verschoben: +[0-9]+' | grep -oE '[0-9]+$'); logged=$(grep -c 'VERSCHOBEN:' "$LOG")
check T17 "Zusammenfassung 'Verschoben' ($moved) entspricht den VERSCHOBEN-Zeilen im Log ($logged)" test "$moved" = "$logged"

# ---------------- --include-cache ----------------
fresh; run1 --run --include-cache
check T04 "Ordner, der nur auf dem Cache liegt, wird mit --include-cache aufs Array geholt (Delta)" \
    test "$(nfiles "/mnt/cache/Filme/Delta (2022)")" = 0 -a "$(nfiles /mnt/disk1/Filme/Delta* /mnt/disk2/Filme/Delta* /mnt/disk10/Filme/Delta*)" = 2
check T04b "Charlie.mkv vom Cache zur nfo auf disk2 geholt" \
    test -f "/mnt/disk2/Filme/Charlie (2021)/Charlie (2021).mkv"

# ---------------- Dryrun ----------------
fresh; before=$(snap); run1; after=$(snap)
check T19 "Dryrun verändert nichts auf den Disks" test "$before" = "$after"
check T19b "Dryrun schreibt nicht ins Log" test ! -s "$LOG"
check T23 "Dryrun-Deep-Clean zeigt auch übergeordnete leere Ordner (Mike (2011) komplett)" \
    grep -q 'LEER\] /mnt/disk2/Filme/Mike (2011)$' <<< "$OUT"

# ---------------- Deep Clean: nicht löschbarer leerer Ordner ----------------
fresh; mkdir -p "/mnt/disk2/Filme/Zulu (2000)/stuck"; mount -t tmpfs -o size=1m tmpfs "/mnt/disk2/Filme/Zulu (2000)/stuck"
start=$(date +%s); run1 --run; dur=$(( $(date +%s) - start ))
umount "/mnt/disk2/Filme/Zulu (2000)/stuck" 2>/dev/null
check T14 "Deep Clean terminiert, wenn ein leerer Ordner nicht löschbar ist (${dur}s, rc=$RC)" test "$RC" != 124

# ---------------- Volle Disk ----------------
fresh "MIN_FREE_GB=999999"; run1 --run
check T16 "Volle Ziel-Disk: gescheiterte Moves stehen im Log" grep -qiE 'VOLL|FULL' "$LOG"
check T16b "Volle Ziel-Disk: gescheiterte Moves auf der Konsole sichtbar (scharfer Modus)" grep -qE 'VOLL\]|FULL\]' <<< "$OUT"

# ---------------- rsync-Fehler ----------------
fresh; chattr +i "/mnt/disk1/Filme/Alpha (2020)"; run1 --run; chattr -i "/mnt/disk1/Filme/Alpha (2020)"
moved=$(printf '%s' "$OUT" | grep -oE 'Verschoben: +[0-9]+' | grep -oE '[0-9]+$'); logged=$(grep -c 'VERSCHOBEN:' "$LOG")
check T17b "rsync-Fehler werden nicht als 'Verschoben' gezählt (Zusammenfassung $moved, Log $logged)" test "$moved" = "$logged"
check T17c "rsync-Fehler erscheinen als Fehler in der Zusammenfassung / Exit-Code != 0 (rc=$RC)" bash -c 'grep -qE "Fehler" "$1" && [ "$2" != 0 ]' _ "$WORK/last.out" "$RC"

# ---------------- Suffix-Treffer ----------------
fresh; mkdir -p "/mnt/disk2/Filme/Box/Filme/Alpha (2020)"; head -c 1M /dev/urandom > "/mnt/disk2/Filme/Box/Filme/Alpha (2020)/Alpha (2020).mkv"
run1 --run
check T18 "Gleichnamige Datei in tieferem Unterordner gilt nicht als Kopie (Alpha bleibt erhalten)" \
    test "$(stat -c%s "/mnt/disk1/Filme/Alpha (2020)/Alpha (2020).mkv" 2>/dev/null)" = 5242880 -a -f "/mnt/disk2/Filme/Box/Filme/Alpha (2020)/Alpha (2020).mkv"

# ---------------- Konfig-Validierung ----------------
fresh "DRYRUN=1"; before=$(snap); run1; after=$(snap)
check T15 "DRYRUN=1 in der ini führt NICHT zu einem scharfen Lauf" test "$before" = "$after"
check T15b "DRYRUN=1 wird als Konfigfehler abgewiesen (rc=$RC)" test "$RC" != 0
fresh "DRYRUN=yes"; run1
check T15c "DRYRUN=yes hängt nicht (kein 'yes'-Endlosoutput), rc=$RC" bash -c '[ "$1" != 124 ] && ! grep -qx y "$2"' _ "$RC" "$WORK/last.out"
fresh "MIN_FREE_GB=256GB"; run1
check T24 "MIN_FREE_GB=256GB wird sauber abgewiesen statt Arithmetikfehler (rc=$RC)" bash -c '[ "$1" != 0 ] && ! grep -q "value too great" "$2"' _ "$RC" "$WORK/last.out"

# ---------------- Log-Ordner fehlt ----------------
fresh; sed -i "s#^LOGFILE=.*#LOGFILE=\"$WORK/logs/neu/sub/consolidate.log\"#" "$SUT/consolidate.ini"; run1 --run
check T20 "Fehlender Log-Ordner: kein Fehler-Spam, Log wird angelegt oder Lauf sauber abgebrochen" \
    bash -c '! grep -q "No such file or directory" "$1" && { [ -s "$3" ] || [ "$2" != 0 ]; }' _ "$WORK/last.out" "$RC" "$WORK/logs/neu/sub/consolidate.log"

# ---------------- Ergebnis ----------------
echo "================ Testsuite gegen: $SUT ================"
printf '%s\n' "${RESULTS[@]}"
echo "-----------------------------------------------------"
echo "PASS: $PASS   FAIL: $FAIL"
rm -f "$SUT/consolidate.ini"
